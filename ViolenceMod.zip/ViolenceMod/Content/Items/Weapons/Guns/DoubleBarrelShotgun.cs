﻿using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace ViolenceMod.Content.Items.Weapons.Guns
{

    public class DoubleBarrelShotgun : ModItem
    {

        public override void SetDefaults()
        {

            Item.height = 18;
            Item.width = 56;

            Item.useTime = 30;
            Item.useAnimation = 30;

            Item.useStyle = ItemUseStyleID.Shoot;
            Item.autoReuse = true;

            Item.DamageType = DamageClass.Ranged;
            Item.damage = 20;
            Item.knockBack = 4f;
            Item.noMelee = true;


            Item.shoot = ProjectileID.PurificationPowder;
            Item.shootSpeed = 10f;
            Item.useAmmo = AmmoID.Bullet;
            Item.UseSound = SoundID.Item36;


        }

        public override void AddRecipes()
        {

            CreateRecipe()
                .AddIngredient(ItemID.Wood, 5)
                .AddIngredient(ItemID.IronBar, 10)
                .AddTile(TileID.Anvils)
                .Register();

            CreateRecipe()
               .AddIngredient(ItemID.Wood, 5)
               .AddIngredient(ItemID.LeadBar, 10)
               .AddTile(TileID.Anvils)
               .Register();
        }

        public override Vector2? HoldoutOffset()
        {
            return new Vector2(-8f, -1f);
        }

        public override bool Shoot(Player player, EntitySource_ItemUse_WithAmmo source, Vector2 position, Vector2 velocity, int type, int damage, float knockback)
        {
            for (int i = 0; i < 2; i++)
            {
                Vector2 newVelocity = velocity.RotatedByRandom(MathHelper.ToRadians(5)); // Slight spread
                Projectile.NewProjectile(source, position, newVelocity, type, damage, knockback, player.whoAmI);
            }

            Item.reuseDelay = 30;
            return false;
        }


    }

}
