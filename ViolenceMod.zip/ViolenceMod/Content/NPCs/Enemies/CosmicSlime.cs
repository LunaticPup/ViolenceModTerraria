﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.GameContent;
using Terraria.GameContent.Bestiary;
using Terraria.GameContent.ItemDropRules;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.Utilities;

namespace ViolenceMod.Content.NPCs.Enemies
{
   
    internal class CosmicSlime : ModNPC
    {

        public override void SetStaticDefaults()
        {
            Main.npcFrameCount[Type] = Main.npcFrameCount[NPCID.BlueSlime];

            NPCID.Sets.ShimmerTransformToNPC[NPC.type] = NPCID.BlueSlime;

            NPCID.Sets.NPCBestiaryDrawModifiers value = new()
            {

                Velocity = 1f

            };
            NPCID.Sets.NPCBestiaryDrawOffset.Add(Type, value);
        }

        public override void SetDefaults()
        {

            NPC.CloneDefaults(NPCID.BlueSlime);

            AIType = NPCID.BlueSlime;
            AnimationType = NPCID.BlueSlime;


            Banner = NPCID.BlueSlime;
            BannerItem = Item.BannerToItem(Banner);

        }

        public override void ModifyNPCLoot(NPCLoot npcLoot)
        {

            var CosmicSlimeDrops = Main.ItemDropsDB.GetRulesForNPCID(NPCID.BlueSlime);
            foreach(var rule in  CosmicSlimeDrops)
            {

                npcLoot.Add(rule);

            }

            

        }

        public override float SpawnChance(NPCSpawnInfo spawnInfo)
        {
            return SpawnCondition.Cavern.Chance - 0.65f;

        }

        public override void SetBestiary(BestiaryDatabase database, BestiaryEntry bestiaryEntry)
        {
            bestiaryEntry.Info.AddRange(new IBestiaryInfoElement[]
            {

                BestiaryDatabaseNPCsPopulator.CommonTags.SpawnConditions.Times.DayTime,
                new FlavorTextBestiaryInfoElement("A volitile slime containing key ingridents for alchemical projects.")

            });
        }

    }

}
