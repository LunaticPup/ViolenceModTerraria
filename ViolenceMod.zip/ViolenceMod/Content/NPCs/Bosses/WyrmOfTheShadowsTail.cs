using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace ViolenceMod.Content.NPCs.Bosses
{
    public class WyrmOfTheShadowsTail : ModNPC
    {
        public override void SetDefaults()
        {
            NPC.width = 48;
            NPC.height = 48;
            NPC.damage = 40;
            NPC.defense = 30;
            NPC.lifeMax = 1800;
            NPC.knockBackResist = 0f;
            NPC.aiStyle = -1; // Custom AI
            NPC.noTileCollide = true;
            NPC.noGravity = true;
            NPC.behindTiles = true;
        }

        public override void AI()
        {
            // Tail segment follows the head's AI (as defined in the realLife and ai chaining)
            NPC.aiStyle = 6;
            AIType = NPCID.EaterofWorldsTail; // Uses the Eater of Worlds tail AI
        }
    }
}
