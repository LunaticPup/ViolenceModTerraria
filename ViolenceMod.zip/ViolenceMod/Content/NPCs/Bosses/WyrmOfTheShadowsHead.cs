using Terraria;
using Terraria.GameContent.Bestiary;
using Terraria.ID;
using Terraria.ModLoader;

namespace ViolenceMod.Content.NPCs.Bosses
{
    public class WyrmOfTheShadowsHead : ModNPC
    {
        public override void SetStaticDefaults()
        {
            Main.npcFrameCount[NPC.type] = 1; // Set number of frames (can adjust if animated)

            NPCID.Sets.NPCBestiaryDrawModifiers value = new()
            {

                Velocity = 1f

            };
            NPCID.Sets.NPCBestiaryDrawOffset.Add(Type, value);

        }

        public override void SetDefaults()
        {
            NPC.width = 74;
            NPC.height = 74;
            NPC.damage = 90;
            NPC.defense = 10;
            NPC.lifeMax = 2500;
            NPC.knockBackResist = 0f;
            NPC.aiStyle = -1; // Custom AI
            NPC.boss = true;
            NPC.noTileCollide = true;
            NPC.noGravity = true;
            NPC.behindTiles = true;

            if (!Main.dedServ)
            {
                Music = MusicLoader.GetMusicSlot(Mod, "Assets/Music/Infested_HeartbeatGM");
            }
        }
        public override void AI()
        {
            if (NPC.ai[0] == 0) // If this is the head
            {
                if (Main.netMode != NetmodeID.MultiplayerClient)
                {
                    // Spawn body and tail segments
                    int previousNPC = NPC.whoAmI;
                    for (int i = 0; i < 100; i++) // Number of body segments
                    {
                        int bodyNPC = NPC.NewNPC(NPC.GetSource_FromAI(), (int)NPC.Center.X, (int)NPC.Center.Y, ModContent.NPCType<WyrmOfTheShadowsBody>(), NPC.whoAmI);
                        Main.npc[bodyNPC].realLife = NPC.whoAmI;
                        Main.npc[bodyNPC].ai[1] = previousNPC;
                        Main.npc[previousNPC].ai[0] = bodyNPC;
                        previousNPC = bodyNPC;
                    }

                    int tailNPC = NPC.NewNPC(NPC.GetSource_FromAI(), (int)NPC.Center.X, (int)NPC.Center.Y, ModContent.NPCType<WyrmOfTheShadowsTail>(), NPC.whoAmI);
                    Main.npc[tailNPC].realLife = NPC.whoAmI;
                    Main.npc[tailNPC].ai[1] = previousNPC;
                    Main.npc[previousNPC].ai[0] = tailNPC;
                }

                NPC.ai[0] = 1; // Prevent this AI from running again
            }

            // Basic worm movement using Eater of Worlds Head AI for now
            NPC.aiStyle = 6;
            AIType = NPCID.EaterofWorldsHead; // Uses the Eater of Worlds head AI
        }

        public override void OnKill()
        {
            // Add drops and effects here once finished
        }

        public override void SetBestiary(BestiaryDatabase database, BestiaryEntry bestiaryEntry)
        {
            bestiaryEntry.Info.AddRange(new IBestiaryInfoElement[]
            {
              
                new MoonLordPortraitBackgroundProviderBestiaryInfoElement(),
                new FlavorTextBestiaryInfoElement("Sometimes the shadows birth something new...")


            });
        }
    }
}
