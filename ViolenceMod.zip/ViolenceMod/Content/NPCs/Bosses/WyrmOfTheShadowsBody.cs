using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace ViolenceMod.Content.NPCs.Bosses
{
    public class WyrmOfTheShadowsBody : ModNPC
    {
        public override void SetDefaults()
        {
            NPC.width = 48;
            NPC.height = 48;
            NPC.damage = 50;
            NPC.defense = 20;
            NPC.lifeMax = 2000;
            NPC.knockBackResist = 0f;
            NPC.aiStyle = -1; // Custom AI
            NPC.noTileCollide = true;
            NPC.noGravity = true;
            NPC.behindTiles = true;
        }

        public override void AI()
        {
            // Body segment follows the head's AI (as defined in the realLife and ai chaining)
            NPC.aiStyle = 6;
            AIType = NPCID.EaterofWorldsBody; // Uses the Eater of Worlds body AI
        }
    }
}
